import React from "react";

const CountContext = React.createContext();

export default CountContext;
